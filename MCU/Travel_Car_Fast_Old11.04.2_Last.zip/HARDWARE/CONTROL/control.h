#ifndef __CONTROL_H
#define __CONTROL_H

void track_zhixian(void);
void track_zhixian_Po(void);
void Sensor_Get(void);
void XianFu(void);
void track_zhixian_PID();
int Zhijiao_Detect(void);
//void track_PID(int pwm,float P);
#endif
