#ifndef __SENSOR8_H
#define __SENSOR8_H
#include "main.h"

//void Sensor_Init(void);
//int Read_Data1(void);
//void Read_Data(int *Data);		

#endif 
