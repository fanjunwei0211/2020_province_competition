#ifndef __MOTOR_H
#define __MOTOR_H



void Motor_Start(void);
void Set_Pwm(int moto1, int moto2, int moto3, int moto4);
void Set_Pwm1(int moto);

#endif
